package mx.unam.progavanzada.tareapractica.ejercicio16;

 interface Carnivoro{
    public void comerCarne();
}