package mx.unam.progavanzada.practica.ejercicio16;

public interface Carnivoro {
	public void comerCarne();
}
