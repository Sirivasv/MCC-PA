package mx.unam.progavanzada.practica.ejercicio16;


public interface Herbivoro{
	public void comerHierba();
}
