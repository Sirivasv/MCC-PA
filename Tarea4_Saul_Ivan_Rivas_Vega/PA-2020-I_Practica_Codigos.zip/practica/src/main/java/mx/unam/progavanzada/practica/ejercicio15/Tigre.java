package mx.unam.progavanzada.practica.ejercicio15;

public class Tigre extends Animal {

	@Override
	public void comunicar() {
		System.out.println("ROOOOOOOOOOOOOOOOARRRR!!!");
	}

}
