package mx.unam.progavanzada.practica.ejercicio15;

public class Vaca extends Animal {

	@Override
	public void comunicar() {
		System.out.println("MUUUUUUUUUUUUuuuuuuuuuuuuUUUUUUUUUUUUUUUUuuuuuuuuuUUUUUUUuu");
	}

}
