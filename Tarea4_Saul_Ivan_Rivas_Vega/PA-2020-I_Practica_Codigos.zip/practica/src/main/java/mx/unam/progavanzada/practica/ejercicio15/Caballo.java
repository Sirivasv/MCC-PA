package mx.unam.progavanzada.practica.ejercicio15;

public class Caballo extends Animal{

	@Override
	public void comunicar() {
		System.out.println("<inserte sonido de caballo>");
	}

}
