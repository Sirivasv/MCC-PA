package mx.unam.progavanzada.tareapractica.ejercicio15;

public class Caballo extends Animal{
    @Override
    public void comunicar() {
        System.out.println("RjEEeeEEeEey");
    }
}