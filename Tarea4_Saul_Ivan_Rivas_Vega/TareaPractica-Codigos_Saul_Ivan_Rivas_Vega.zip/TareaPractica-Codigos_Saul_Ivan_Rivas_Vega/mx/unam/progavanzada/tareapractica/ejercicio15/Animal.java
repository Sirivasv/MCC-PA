package mx.unam.progavanzada.tareapractica.ejercicio15;

public abstract class Animal {
    public abstract void comunicar();
}