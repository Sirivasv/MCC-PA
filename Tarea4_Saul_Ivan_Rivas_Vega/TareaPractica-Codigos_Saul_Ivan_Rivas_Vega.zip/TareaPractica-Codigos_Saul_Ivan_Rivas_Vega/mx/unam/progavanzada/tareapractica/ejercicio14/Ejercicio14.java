package mx.unam.progavanzada.tareapractica.ejercicio14;

public class Ejercicio14 {
    public static void main(String args[]) {
        UsoMatrizExtendida um = new UsoMatrizExtendida();
        um.leerN();
        um.imprimeMatriz();
        um.preguntarCambiarValor();

    }
}