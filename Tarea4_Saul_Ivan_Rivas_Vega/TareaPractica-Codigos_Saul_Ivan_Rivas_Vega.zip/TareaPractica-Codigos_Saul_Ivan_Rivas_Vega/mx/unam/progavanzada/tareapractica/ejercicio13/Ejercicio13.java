package mx.unam.progavanzada.tareapractica.ejercicio13;

public class Ejercicio13 {
    public static void main(String args[]) {
        
        UsoMatriz um = new UsoMatriz();
        um.leerN();
        um.imprimeMatriz();

    }
}