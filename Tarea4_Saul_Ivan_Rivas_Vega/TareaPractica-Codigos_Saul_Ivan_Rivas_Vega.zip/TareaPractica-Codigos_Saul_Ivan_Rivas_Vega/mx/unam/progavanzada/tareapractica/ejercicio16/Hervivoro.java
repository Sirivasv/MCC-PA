package mx.unam.progavanzada.tareapractica.ejercicio16;

 interface Hervivoro{
    public void comerHierba();
}