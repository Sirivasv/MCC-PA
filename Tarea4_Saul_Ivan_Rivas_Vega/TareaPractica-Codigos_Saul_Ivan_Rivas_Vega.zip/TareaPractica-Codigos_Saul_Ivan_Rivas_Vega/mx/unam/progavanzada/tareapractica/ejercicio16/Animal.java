package mx.unam.progavanzada.tareapractica.ejercicio16;

public abstract class Animal {
    public abstract void comunicar();
}