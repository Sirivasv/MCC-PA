package mx.unam.progavanzada.tareapractica.ejercicio15;

public class Tigre extends Animal{
    @Override
    public void comunicar() {
        System.out.println("Rwaar");
    }
}